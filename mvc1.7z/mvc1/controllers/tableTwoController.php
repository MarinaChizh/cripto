<?php

class tableTwoController extends tableController {

    public $table_name = 'joke';

}

?>