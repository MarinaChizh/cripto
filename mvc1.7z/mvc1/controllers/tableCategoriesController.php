<?php

class tableCategoriesController extends tableController {

    public $table_name = 'categories';

    function __construct($view) {
        parent::__construct($view);

        $this->view->setlayoutPath("views/layouts/cleanLayout.php")->setviewPath('views/categories/');

}
}

?>