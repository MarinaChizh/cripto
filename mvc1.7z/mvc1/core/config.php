<?php

    
    $conf['host'] = 'localhost';
    $conf['user'] = 'root';
    $conf['password'] = '';
    $conf['db'] = 'internet';
    // $conf['page_size'] = '3';

?>